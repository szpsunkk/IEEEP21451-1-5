1. 需要先更换清华源
2. 运行 pre中的命令
3. 在/python/example文件下，查看screeShow.py 文件。